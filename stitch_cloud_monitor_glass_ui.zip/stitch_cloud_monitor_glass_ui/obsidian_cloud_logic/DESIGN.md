---
name: Obsidian Cloud Logic
colors:
  surface: '#f8f9fb'
  surface-dim: '#d9dadc'
  surface-bright: '#f8f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#edeef0'
  surface-container-high: '#e7e8ea'
  surface-container-highest: '#e1e2e4'
  on-surface: '#191c1e'
  on-surface-variant: '#444655'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f3'
  outline: '#757687'
  outline-variant: '#c4c5d8'
  surface-tint: '#2b4be6'
  primary: '#173cda'
  on-primary: '#ffffff'
  primary-container: '#3b59f2'
  on-primary-container: '#eaeaff'
  inverse-primary: '#bac3ff'
  secondary: '#565e71'
  on-secondary: '#ffffff'
  secondary-container: '#d7e0f6'
  on-secondary-container: '#5a6376'
  tertiary: '#3c3cca'
  on-tertiary: '#ffffff'
  tertiary-container: '#5658e3'
  on-tertiary-container: '#eceaff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dee0ff'
  primary-fixed-dim: '#bac3ff'
  on-primary-fixed: '#00105b'
  on-primary-fixed-variant: '#002fc9'
  secondary-fixed: '#dae2f9'
  secondary-fixed-dim: '#bec6dd'
  on-secondary-fixed: '#131c2c'
  on-secondary-fixed-variant: '#3e4759'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#f8f9fb'
  on-background: '#191c1e'
  surface-variant: '#e1e2e4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  kpi-value:
    fontFamily: JetBrains Mono
    fontSize: 27px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  title-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-base:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10.5px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.12em
  micro-tag:
    fontFamily: JetBrains Mono
    fontSize: 9.5px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  panel-gap: 22px
  container-max: 1140px
---

## Brand & Style

The design system is engineered for high-density observability, blending the precision of technical telemetry with a refined, contemporary aesthetic. It targets DevOps engineers and system architects who require clarity under cognitive load. The UI evokes a sense of "calm authority"—professional, reliable, and meticulously organized.

The design style is **Modern Minimalism with Glassmorphic Depth**. It utilizes a "Paper and Ink" foundation, where a soft off-white canvas serves as the backdrop for pure white elevated containers. Depth is not merely decorative but functional, using frosted glass overlays and multi-layered ambient shadows to separate active monitoring tools from background data. The visual narrative is driven by high-contrast typography, generous corner radii, and a strict adherence to a technical, geometric structure.

## Colors

The palette is anchored by a high-clarity neutral scale and professional technical accents.

- **Primary (Sapphire Blue):** Used for brand anchors, primary actions, and active states. It represents the "pulse" of the system.
- **Secondary (Deep Navy):** Reserved for high-emphasis typography and core structural elements to provide a grounded, authoritative feel.
- **Surface Scale:** The background uses a soft off-white (`#f6f7f9`), while cards and panels use pure white (`#ffffff`) to create a clear "layered" hierarchy.
- **Semantic Accents:**
    - **Emerald Green:** Healthy status and successful telemetry.
    - **Soft Amber:** Quota limits, warnings, and generated outputs.
    - **Periwinkle/Violet:** Distinct token flows (input vs. cache writes).
    - **Critical Red:** Disconnections and system errors.

## Typography

The typography system uses a dual-font approach to distinguish between interface guidance and raw telemetry.

1.  **Interface Sans (Inter):** Used for all UI labels, headings, and descriptive text. It provides a clean, neutral, and highly readable foundation.
2.  **Telemetry Mono (JetBrains Mono):** Used for all numerical data, timestamps, IDs, and status tags. This ensures tabular alignment in data tables and metric cards, allowing for easy comparison of fluctuating values.

**Scaling Rules:**
- On mobile, `display-lg` should scale down to `24px` to maintain screen real estate.
- All monospace data should maintain its size across devices to ensure legibility of technical metrics.
- Utilize `font-variant-numeric: tabular-nums` for all components displaying shifting numbers.

## Layout & Spacing

The system follows a **Fluid Card Grid** model with a strict 4px/8px baseline rhythm.

- **Desktop:** A 12-column grid with 24px margins. Layouts are card-based, utilizing a 22px "Panel Gap" between primary containers.
- **Tablet:** Containers reflow to 2-column or single-column stacks. Horizontal margins reduce to 16px.
- **Mobile:** All metric cards stack vertically. Touch targets for segment controls and buttons expand to a minimum of 40px height.

**Spacing Philosophy:**
Layout is defined by "density zones." Primary dashboards use `lg` (24px) padding for breathing room around high-level KPIs, while data tables and device fleet lists use `sm` (8px) or `md` (16px) internal padding to maximize information density.

## Elevation & Depth

Hierarchy is established through **Tonal Layering** and **Ambient Depth**:

- **Level 0 (Canvas):** The off-white background (`#f6f7f9`).
- **Level 1 (Cards):** Pure white surfaces with a soft 1px border (`#e9ecf1`). These use a low-opacity, wide-spread shadow to appear slightly lifted.
- **Level 2 (Active/Hover):** When hovered, cards lift (`translateY(-2px)`) and the shadow deepens to create a "tactile" response.
- **Level 3 (Overlays/Glass):** Tooltips, dropdowns, and modals use **Glassmorphism**. They feature a semi-transparent white background with a 14px backdrop blur and a more pronounced multi-layered shadow.

Shadow Character: Shadows should be diffused and tinted with a hint of the secondary color (`#0d1626`) at very low opacity (3-5%) to avoid a "dirty" look on the off-white canvas.

## Shapes

The shape language is defined by "Generous Enclosures." 

- **Primary Containers:** All cards, panels, and large modals use a `rounded-xl` (1.5rem / 24px) radius to soften the technical nature of the data.
- **Controls:** Buttons and segmented pickers use pill-shaped (999px) geometry to create a clear distinction between "containers" and "interactables."
- **Data Cells:** Smaller elements like heat-grid cells and table row highlights use a tighter `rounded-sm` (4px) radius to maintain grid alignment and density.

## Components

- **Stat Cards:** Feature a top-aligned `micro-tag` (e.g., "TODAY"), followed by a large `kpi-value`. Below the value, include a 10px tall segmented "Progress Bar" using semantic colors (Input, Output, Cache) with subtle glow effects.
- **Buttons:** 
  - **Primary:** Solid Sapphire Blue with white text and pill-shaped geometry.
  - **Secondary:** Ghost style with a `outline-strong` border and Navy Ink text.
- **Segmented Controls:** A pill-shaped track with a sliding white or indigo "capsule" that glides behind the options using a 250ms smooth curve.
- **Data Tables:** Headers utilize a glassmorphic effect (backdrop blur) when scrolling. Cell text is strictly `data-mono` for vertical alignment.
- **Progress Rings:** Used for quota limits. They should use a thick stroke with a rounded cap. Colors transition from Emerald (OK) to Amber (Warning) to Red (Critical) based on the percentage filled.
- **Fleet Cards:** Feature a `status-dot` with a 3px ambient pulsing ring to indicate real-time connectivity.
- **Tooltips:** Pure glassmorphism. White 80% opacity, 14px blur, and 8px padding with `data-mono` content.